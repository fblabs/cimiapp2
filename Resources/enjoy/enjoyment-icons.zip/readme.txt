"Enjoyment v.1" icons set by Icojoy.com

Ammount of icons:
4

Icon Sizes:
256x256, 128x128, 48x48, 32x32

File Types:
.ico (RGBA, 256 color, 16 color)
.icns (RGBA, 256 color, 16 color)
.tif (RGBA)
.gif (indexed)
.bmp (RGB with 1 color for background)
.png (RGBA)
.psd (RGBA icons and layers with shadows)

Versions with shadows and without shadows are included

Note: These icons are free for use.